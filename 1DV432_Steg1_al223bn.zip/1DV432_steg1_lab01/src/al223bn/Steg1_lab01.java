package al223bn;


/** 
 * This assignment lets a user calculate his or hers electricity costs for each month.
 *
 * @version 1.0
 * @author Andreas Lengqvist
 * Created 12:50, June 8, 2015.
 */
public class Steg1_lab01 {

	public static void main(String[] args) {
		
		ConsumptionCalculator consumptioncalculator = new ConsumptionCalculator();
		consumptioncalculator.show();
	}
}
