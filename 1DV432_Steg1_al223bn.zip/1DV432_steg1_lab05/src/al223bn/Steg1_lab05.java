package al223bn;


/** 
 * This assignment lets a user enter a three digit value which then is summed together.
 *
 * @version 1.0
 * @author Andreas Lengqvist
 * Created 13:50, June 8, 2015.
 */
public class Steg1_lab05 {

	public static void main(String[] args) {
		
		SumDigits sumdigits = new SumDigits();		
		sumdigits.show();
	}
}
