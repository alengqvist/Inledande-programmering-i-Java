package al223bn;

@SuppressWarnings("serial")
public class CashDispenserException extends Exception {

	public CashDispenserException() {
		
	}
	
	public CashDispenserException(String message) {
		super(message); 
	}
}
