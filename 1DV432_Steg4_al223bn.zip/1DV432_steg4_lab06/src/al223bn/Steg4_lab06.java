package al223bn;



/** 
 * This program handles the CRUD of register of Media.
 *
 * @version 1.0
 * @author Andreas Lengqvist
 * Created 12:40, June 30, 2015.
 */
public class Steg4_lab06 {

	public static void main(String[] args) {
		
		MediaController mediaController = new MediaController();
		mediaController.run();
	}
}